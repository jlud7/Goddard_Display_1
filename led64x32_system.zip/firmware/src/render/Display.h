#pragma once
#include <ESP32-HUB75-MatrixPanel-I2S-DMA.h>
#include "../util/Log.h"
#include "../config.h"
#include "Canvas565.h"

class Display {
public:
  bool begin() {
    HUB75_I2S_CFG mxconfig(
      PANEL_RES_X, PANEL_RES_Y, PANEL_CHAIN
    );

    mxconfig.gpio.r1 = PIN_R1;
    mxconfig.gpio.g1 = PIN_G1;
    mxconfig.gpio.b1 = PIN_B1;
    mxconfig.gpio.r2 = PIN_R2;
    mxconfig.gpio.g2 = PIN_G2;
    mxconfig.gpio.b2 = PIN_B2;
    mxconfig.gpio.a  = PIN_A;
    mxconfig.gpio.b  = PIN_B;
    mxconfig.gpio.c  = PIN_C;
    mxconfig.gpio.d  = PIN_D;
    mxconfig.gpio.e  = PIN_E;
    mxconfig.gpio.lat= PIN_LAT;
    mxconfig.gpio.oe = PIN_OE;
    mxconfig.gpio.clk= PIN_CLK;

    mxconfig.clkphase = false;
    mxconfig.driver = HUB75_I2S_CFG::SHIFTREG;
    mxconfig.i2sspeed = HUB75_I2S_CFG::HZ_20M; // adjust if needed
    mxconfig.latch_blanking = 2;

    _matrix = new MatrixPanel_I2S_DMA(mxconfig);
    if (!_matrix->begin()) {
      Log::err("Display", "Matrix begin failed");
      return false;
    }
    setBrightness(DEFAULT_BRIGHTNESS);

    _front = new uint16_t[PANEL_RES_X * PANEL_RES_Y];
    _back  = new uint16_t[PANEL_RES_X * PANEL_RES_Y];
    memset(_front, 0, PANEL_RES_X * PANEL_RES_Y * 2);
    memset(_back, 0, PANEL_RES_X * PANEL_RES_Y * 2);

    _frontCanvas = new Canvas565(PANEL_RES_X, PANEL_RES_Y, _front);
    _backCanvas  = new Canvas565(PANEL_RES_X, PANEL_RES_Y, _back);
    return true;
  }

  void setBrightness(uint8_t b) {
    _brightness = b;
    if (_matrix) _matrix->setBrightness8(b);
  }
  uint8_t brightness() const { return _brightness; }

  Canvas565& back() { return *_backCanvas; }

  void swapAndShow() {
    // swap pointers
    uint16_t* tmp = _front; _front = _back; _back = tmp;
    Canvas565* tc = _frontCanvas; _frontCanvas = _backCanvas; _backCanvas = tc;

    // blit front buffer to matrix
    // Use drawPixelRGB565 for correctness; this is fast enough at 64x32.
    // If you chain larger panels later, optimize with direct buffer APIs.
    for (int y=0; y<PANEL_RES_Y; y++){
      for (int x=0; x<PANEL_RES_X; x++){
        uint16_t c = _front[(size_t)y*PANEL_RES_X + x];
        _matrix->drawPixel(x, y, c);
      }
    }
    _matrix->flipDMABuffer();
  }

private:
  MatrixPanel_I2S_DMA* _matrix = nullptr;
  uint8_t _brightness = DEFAULT_BRIGHTNESS;

  uint16_t* _front = nullptr;
  uint16_t* _back = nullptr;
  Canvas565* _frontCanvas = nullptr;
  Canvas565* _backCanvas = nullptr;
};
