#include <Arduino.h>
#include "config.h"
#include "util/Log.h"
#include "render/Display.h"
#include "Controller.h"
#include "net/Net.h"
#include "net/ApiServer.h"

static Display display;
static Controller controller;
static ApiServer* api = nullptr;

static uint32_t lastTick = 0;

void setup() {
  Serial.begin(115200);
  delay(200);

  Log::info("Boot", "Starting");

  if (!display.begin()) {
    Log::err("Boot", "Display init failed; check HUB75 pins in config.h");
    while(true) delay(1000);
  }

  controller.begin();

  if (!Net::setupWifi()) {
    // If you want: start AP setup mode here (not included to keep this build deterministic).
    while(true) delay(1000);
  }
  Net::setupMDNS();
  Net::setupTime();

  api = new ApiServer(controller, display);
  api->begin();

  lastTick = millis();
}

void loop() {
  uint32_t now = millis();
  uint32_t dt = now - lastTick;
  lastTick = now;

  controller.tick(dt);
  controller.render(display.back());
  display.swapAndShow();

  if (api) api->tickEvents(now);

  delay(1);
}
