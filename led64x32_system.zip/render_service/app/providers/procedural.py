import math
import random
from PIL import Image, ImageDraw
from .base import Provider

class ProceduralProvider(Provider):
    def image(self, prompt: str, seed: int | None = None) -> Image.Image:
        rng = random.Random(seed)
        prompt_l = prompt.lower()
        if "dragon" in prompt_l:
            return self._dragon_frame(t=0.0, rng=rng)
        if "mario" in prompt_l:
            return self._retro_plumber(rng=rng)
        if "metroid" in prompt_l:
            return self._metroid(rng=rng)
        if "zelda" in prompt_l:
            return self._zelda(rng=rng)
        if "pikachu" in prompt_l or "pokemon" in prompt_l:
            return self._pikachu(rng=rng)
        return self._abstract(prompt, rng=rng)

    def animation(self, prompt: str, frames: int, seed: int | None = None) -> list[Image.Image]:
        rng = random.Random(seed)
        prompt_l = prompt.lower()
        if "dragon" in prompt_l and ("fire" in prompt_l or "breath" in prompt_l):
            return [self._dragon_frame(t=i/(frames-1), rng=rng) for i in range(frames)]
        if "rain" in prompt_l:
            return [self._rain_frame(i, rng=rng) for i in range(frames)]
        if "time" in prompt_l:
            return [self._clock_orbit_frame(i, frames, rng=rng) for i in range(frames)]
        # fallback: animated abstract
        return [self._abstract(prompt, rng=random.Random(rng.randint(0, 10_000_000))) for _ in range(frames)]

    # --- primitives on a higher-res canvas then downscale in pipeline ---
    def _dragon_frame(self, t: float, rng: random.Random) -> Image.Image:
        W, H = 256, 128
        img = Image.new("RGB", (W, H), (5, 6, 12))
        d = ImageDraw.Draw(img)

        # moon + haze
        d.ellipse((180, 10, 230, 60), fill=(200, 210, 255))
        for i in range(8):
            y = 20 + i*10
            d.line((0, y, W, y), fill=(10+i, 10+i, 18+i), width=1)

        # dragon silhouette
        base_x = 60
        base_y = 80
        body = [(base_x-10, base_y), (base_x+30, base_y-30), (base_x+70, base_y-25),
                (base_x+95, base_y-10), (base_x+70, base_y+15), (base_x+25, base_y+10)]
        d.polygon(body, fill=(20, 30, 35))

        # head
        d.ellipse((base_x+75, base_y-45, base_x+115, base_y-15), fill=(22, 34, 40))
        # horn
        d.polygon([(base_x+92, base_y-48), (base_x+102, base_y-65), (base_x+110, base_y-45)], fill=(25, 40, 45))

        # wings
        wing1 = [(base_x+15, base_y-20), (base_x-10, base_y-55), (base_x+20, base_y-60), (base_x+55, base_y-35)]
        d.polygon(wing1, fill=(15, 25, 30))
        wing2 = [(base_x+35, base_y-22), (base_x+10, base_y-65), (base_x+45, base_y-70), (base_x+75, base_y-40)]
        d.polygon(wing2, fill=(14, 22, 28))

        # fire breath (animated)
        mouth = (base_x+115, base_y-30)
        fire_len = 110 + int(30*math.sin(t*math.tau))
        flame_points = []
        for i in range(7):
            px = mouth[0] + (fire_len * i/6)
            jitter = int(8*math.sin(t*math.tau*2 + i) + rng.randint(-2,2))
            py = mouth[1] + jitter + int(10*math.sin(t*math.tau + i*0.7))
            flame_points.append((px, py))
        # thick core
        for i in range(6):
            c = (255, 180 - i*18, 40 + i*10)
            d.line(flame_points[i:i+2], fill=c, width=18 - i*2)
        # sparks
        for _ in range(30):
            sx = mouth[0] + rng.randint(20, fire_len+20)
            sy = mouth[1] + rng.randint(-25, 25)
            if rng.random() < 0.6:
                d.point((sx, sy), fill=(255, 220, 120))

        # ground
        d.rectangle((0, 100, W, H), fill=(8, 10, 14))
        return img

    def _retro_plumber(self, rng: random.Random) -> Image.Image:
        W,H=256,128
        img=Image.new("RGB",(W,H),(20,20,30))
        d=ImageDraw.Draw(img)
        # simple "plumber" sprite blocky
        x,y=90,30
        d.rectangle((x+20,y+0,x+60,y+20), fill=(200,20,20))   # hat
        d.rectangle((x+25,y+20,x+55,y+50), fill=(240,200,160)) # face
        d.rectangle((x+15,y+50,x+65,y+80), fill=(20,80,200))   # overalls
        d.rectangle((x+10,y+80,x+35,y+110), fill=(120,70,30))  # leg
        d.rectangle((x+45,y+80,x+70,y+110), fill=(120,70,30))  # leg
        # bricks
        for bx in range(0,W,24):
            for by in range(0,H,20):
                if by<40:
                    d.rectangle((bx,by,bx+22,by+18), outline=(140,70,20))
        return img

    def _metroid(self, rng: random.Random) -> Image.Image:
        W,H=256,128
        img=Image.new("RGB",(W,H),(5,5,10))
        d=ImageDraw.Draw(img)
        # floating orb
        d.ellipse((90,20,170,100), fill=(40,80,160))
        d.ellipse((105,35,155,85), fill=(120,200,255))
        # tentacles
        for i in range(8):
            x0=130
            y0=80
            x1=60+i*18
            y1=110+rng.randint(-5,5)
            d.line((x0,y0,x1,y1), fill=(180,60,180), width=10)
        return img

    def _zelda(self, rng: random.Random) -> Image.Image:
        W,H=256,128
        img=Image.new("RGB",(12,18,10))
        d=ImageDraw.Draw(img)
        # triforce
        cx,cy=128,64
        size=60
        tri=[(cx,cy-size),(cx-size,cy+size),(cx+size,cy+size)]
        d.polygon(tri, fill=(240,200,40))
        d.polygon([(cx,cy-10),(cx-40,cy+60),(cx+40,cy+60)], fill=(12,18,10))
        # sword
        d.rectangle((30,20,40,110), fill=(180,180,200))
        d.rectangle((20,55,50,65), fill=(200,140,40))
        return img

    def _pikachu(self, rng: random.Random) -> Image.Image:
        W,H=256,128
        img=Image.new("RGB",(W,H),(30,30,40))
        d=ImageDraw.Draw(img)
        # body
        d.rounded_rectangle((90,30,165,110), radius=20, fill=(250,220,60))
        d.ellipse((105,55,120,70), fill=(0,0,0))
        d.ellipse((135,55,150,70), fill=(0,0,0))
        d.ellipse((100,72,120,92), fill=(240,80,80))
        d.ellipse((135,72,155,92), fill=(240,80,80))
        # ears
        d.rectangle((95,10,110,40), fill=(250,220,60))
        d.rectangle((145,10,160,40), fill=(250,220,60))
        d.rectangle((95,10,110,22), fill=(40,40,40))
        d.rectangle((145,10,160,22), fill=(40,40,40))
        # tail
        d.polygon([(165,65),(210,45),(230,60),(195,80),(225,95),(185,105)], fill=(250,220,60))
        return img

    def _rain_frame(self, i: int, rng: random.Random) -> Image.Image:
        W,H=256,128
        img=Image.new("RGB",(W,H),(5,8,16))
        d=ImageDraw.Draw(img)
        # cloud
        d.ellipse((70,10,120,60), fill=(140,150,170))
        d.ellipse((100,0,160,70), fill=(150,160,180))
        d.ellipse((140,10,190,60), fill=(140,150,170))
        d.rectangle((70,35,190,70), fill=(145,155,175))
        # rain streaks
        for x in range(0,W,14):
            y = (i*18 + (x*3)) % H
            d.line((x, y, x-8, y+18), fill=(80,150,255), width=4)
        return img

    def _clock_orbit_frame(self, i: int, n: int, rng: random.Random) -> Image.Image:
        W,H=256,128
        img=Image.new("RGB",(W,H),(0,0,0))
        d=ImageDraw.Draw(img)
        cx,cy=128,64
        d.ellipse((cx-40,cy-40,cx+40,cy+40), outline=(80,80,120), width=3)
        ang = (i/n) * math.tau
        px = cx + int(math.cos(ang)*40)
        py = cy + int(math.sin(ang)*40)
        d.ellipse((px-10,py-10,px+10,py+10), fill=(255,180,60))
        d.line((cx,cy, px,py), fill=(200,200,255), width=3)
        return img

    def _abstract(self, prompt: str, rng: random.Random) -> Image.Image:
        W,H=256,128
        img=Image.new("RGB",(W,H),(0,0,0))
        d=ImageDraw.Draw(img)
        for _ in range(30):
            x0=rng.randint(0,W-1); y0=rng.randint(0,H-1)
            x1=x0+rng.randint(-80,80); y1=y0+rng.randint(-40,40)
            col=(rng.randint(50,255), rng.randint(50,255), rng.randint(50,255))
            d.line((x0,y0,x1,y1), fill=col, width=rng.randint(2,10))
        return img
