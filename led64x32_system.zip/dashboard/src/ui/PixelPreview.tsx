import React, { useEffect, useRef } from "react";
import { H, W, rgb565ToRgb888 } from "../lib/frame";

export function PixelPreview({ frame, scale = 10 }: { frame: Uint16Array | null; scale?: number }) {
  const ref = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    canvas.width = W * scale;
    canvas.height = H * scale;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (!frame) return;

    for (let y=0; y<H; y++) {
      for (let x=0; x<W; x++) {
        const c = frame[y*W + x];
        const [r,g,b] = rgb565ToRgb888(c);
        ctx.fillStyle = `rgb(${r},${g},${b})`;
        ctx.fillRect(x*scale, y*scale, scale, scale);
      }
    }
  }, [frame, scale]);

  return <canvas ref={ref} />;
}
