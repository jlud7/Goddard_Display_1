import React, { useEffect, useMemo, useRef, useState } from "react";
import { decodeB64ToU16LE, makeFramePacketRGB565, W, H } from "../lib/frame";
import { getJson, postJson } from "../lib/api";
import { PixelPreview } from "./PixelPreview";

type ModeId = "clock_fun" | "weather_fun" | "anim_player";

export function App() {
  const [deviceBase, setDeviceBase] = useState<string>("http://led64x32.local");
  const [renderBase, setRenderBase] = useState<string>("http://localhost:8787");
  const [status, setStatus] = useState<any>(null);
  const [mode, setMode] = useState<ModeId>("clock_fun");
  const [brightness, setBrightness] = useState<number>(160);

  const [prompt, setPrompt] = useState<string>("dragon breathing fire");
  const [seed, setSeed] = useState<number>(1234);

  const [frame, setFrame] = useState<Uint16Array | null>(null);
  const [animFrames, setAnimFrames] = useState<Uint16Array[]>([]);
  const [animFps, setAnimFps] = useState<number>(12);

  const wsRef = useRef<WebSocket | null>(null);
  const frameId = useRef<number>(0);

  const frameWsUrl = useMemo(() => {
    try {
      const u = new URL(deviceBase);
      const proto = u.protocol === "https:" ? "wss:" : "ws:";
      return `${proto}//${u.host}/ws/frame`;
    } catch {
      return "";
    }
  }, [deviceBase]);

  async function refreshStatus() {
    const s = await getJson(`${deviceBase}/api/status`);
    setStatus(s);
    setBrightness(s.brightness);
    setMode(s.mode);
  }

  async function connectFrameWs() {
    if (!frameWsUrl) return;
    if (wsRef.current) wsRef.current.close();
    const ws = new WebSocket(frameWsUrl);
    ws.binaryType = "arraybuffer";
    ws.onopen = () => {};
    ws.onclose = () => {};
    ws.onerror = () => {};
    wsRef.current = ws;
  }

  async function setDeviceMode(next: ModeId) {
    await postJson(`${deviceBase}/api/mode`, { mode: next, params: {} });
    setMode(next);
    await refreshStatus();
  }

  async function setDeviceBrightness(val: number) {
    await postJson(`${deviceBase}/api/brightness`, { value: val });
    setBrightness(val);
  }

  async function generateImage() {
    const res = await postJson(`${renderBase}/render/image`, { prompt, seed, style: "pixel_art" });
    const u16 = decodeB64ToU16LE(res.rgb565_b64);
    setFrame(u16);
    setAnimFrames([]);
  }

  async function generateAnim() {
    const res = await postJson(`${renderBase}/render/anim`, { prompt, seed, frames: 24, fps: animFps, style: "pixel_anim" });
    const frames: Uint16Array[] = res.frames_b64.map((b64: string) => decodeB64ToU16LE(b64));
    setAnimFrames(frames);
    setFrame(frames[0] ?? null);
  }

  function sendFrameOnce(u16: Uint16Array) {
    const ws = wsRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) throw new Error("WS not connected");
    const pkt = makeFramePacketRGB565(u16, frameId.current++);
    ws.send(pkt);
  }

  async function playAnimOnDevice() {
    await setDeviceMode("anim_player");
    // send frames at requested fps
    const ws = wsRef.current;
    if (!ws || ws.readyState !== WebSocket.OPEN) throw new Error("WS not connected");
    const frames = animFrames.length ? animFrames : (frame ? [frame] : []);
    if (!frames.length) return;

    let i = 0;
    const interval = Math.max(1, Math.floor(1000 / animFps));
    const timer = setInterval(() => {
      try {
        sendFrameOnce(frames[i]);
        i = (i + 1) % frames.length;
      } catch {
        clearInterval(timer);
      }
    }, interval);

    // stop after 20s; user can click again
    setTimeout(() => clearInterval(timer), 20000);
  }

  async function pushWeather() {
    const w = await getJson(`${renderBase}/weather?location=Miami,FL&units=imperial`);
    if (!w.ok) throw new Error("weather failed");
    const temp = w.current.temp;
    const cond = w.current.condition;
    await setDeviceMode("weather_fun");
    await postJson(`${deviceBase}/api/params`, { params: { tempF: temp, condition: cond, variant: 1 } });
  }

  useEffect(() => {
    refreshStatus().catch(() => {});
  }, []);

  useEffect(() => {
    connectFrameWs().catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [frameWsUrl]);

  return (
    <div>
      <div className="hdr">
        <div className="title">LED 64x32 Dashboard</div>
        <div className="pill">{status ? `Mode: ${status.mode} • Heap: ${status.heapFree}` : "disconnected"}</div>
      </div>

      <div className="grid">
        <div className="card col">
          <div className="row">
            <div className="field" style={{flex: 1}}>
              <div className="label">Device Base URL</div>
              <input value={deviceBase} onChange={(e) => setDeviceBase(e.target.value)} />
              <div className="muted">Examples: http://led64x32.local or http://192.168.1.123</div>
            </div>
            <div className="field" style={{flex: 1}}>
              <div className="label">Render Service URL</div>
              <input value={renderBase} onChange={(e) => setRenderBase(e.target.value)} />
              <div className="muted">Usually http://localhost:8787</div>
            </div>
          </div>

          <div className="row">
            <button className="btn" onClick={() => refreshStatus()}>Refresh status</button>
            <button className="btn" onClick={() => connectFrameWs()}>Reconnect WS</button>
          </div>

          <div className="row">
            <div className="field" style={{minWidth: 240}}>
              <div className="label">Mode</div>
              <select value={mode} onChange={(e) => setDeviceMode(e.target.value as ModeId)}>
                <option value="clock_fun">clock_fun</option>
                <option value="weather_fun">weather_fun</option>
                <option value="anim_player">anim_player</option>
              </select>
            </div>
            <div className="field" style={{minWidth: 240}}>
              <div className="label">Brightness</div>
              <input
                type="range"
                min={0}
                max={255}
                value={brightness}
                onChange={(e) => setBrightness(parseInt(e.target.value, 10))}
                onMouseUp={() => setDeviceBrightness(brightness)}
                onTouchEnd={() => setDeviceBrightness(brightness)}
              />
              <div className="muted">{brightness}</div>
            </div>
          </div>

          <div className="card col" style={{background:"#0e1523"}}>
            <div className="title">Prompt to Pixel Art</div>
            <div className="field">
              <div className="label">Prompt</div>
              <textarea value={prompt} onChange={(e) => setPrompt(e.target.value)} />
            </div>
            <div className="row">
              <div className="field">
                <div className="label">Seed</div>
                <input type="number" value={seed} onChange={(e) => setSeed(parseInt(e.target.value,10))} />
              </div>
              <div className="field">
                <div className="label">Anim FPS</div>
                <input type="number" value={animFps} min={1} max={30} onChange={(e) => setAnimFps(parseInt(e.target.value,10))} />
              </div>
            </div>

            <div className="row">
              <button className="btn btnPrimary" onClick={() => generateImage()}>Generate image</button>
              <button className="btn btnPrimary" onClick={() => generateAnim()}>Generate animation</button>
              <button className="btn" disabled={!frame} onClick={() => { if (frame) { setDeviceMode("anim_player"); sendFrameOnce(frame); } }}>
                Send frame
              </button>
              <button className="btn" disabled={!animFrames.length} onClick={() => playAnimOnDevice()}>
                Play animation on device (20s)
              </button>
              <button className="btn" onClick={() => pushWeather()}>
                Push weather (Miami,FL)
              </button>
            </div>

            <div className="muted">
              This build uses a procedural provider for offline demos. Swap in a real image provider in render_service for true text-to-image.
            </div>
          </div>
        </div>

        <div className="card col">
          <div className="title">Preview (64×32)</div>
          <PixelPreview frame={frame} scale={10} />
          <div className="muted">
            Preview renders RGB565 frames. For best results: short prompts, big shapes, high contrast.
          </div>

          <div className="card col" style={{background:"#0e1523"}}>
            <div className="title">Fun controls</div>
            <div className="row">
              <button className="btn" onClick={() => postJson(`${deviceBase}/api/params`, { params: { style: 0, blink: true } })}>Clock style 0</button>
              <button className="btn" onClick={() => postJson(`${deviceBase}/api/params`, { params: { style: 1, blink: true } })}>Clock style 1</button>
              <button className="btn" onClick={() => postJson(`${deviceBase}/api/params`, { params: { style: 2, blink: false } })}>Clock style 2</button>
            </div>
            <div className="row">
              <button className="btn" onClick={() => { setPrompt("metroid floating orb"); generateImage(); }}>Metroid</button>
              <button className="btn" onClick={() => { setPrompt("mario pixel sprite"); generateImage(); }}>Mario</button>
              <button className="btn" onClick={() => { setPrompt("zelda triforce sword"); generateImage(); }}>Zelda</button>
              <button className="btn" onClick={() => { setPrompt("random pokemon"); generateImage(); }}>Pokémon</button>
              <button className="btn" onClick={() => { setPrompt("dragon breathing fire"); generateAnim(); }}>Dragon anim</button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
