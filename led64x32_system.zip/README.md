# 64x32 HUB75 LED Panel System (ESP32-S3 + Render Service + Dashboard)

This repo contains:
- `firmware/`: ESP32-S3 firmware (PlatformIO, Arduino framework) for 64x32 HUB75 panels using DMA
- `render_service/`: FastAPI service that converts prompts + data into 64x32 pixel-art frames/animations
- `dashboard/`: React (Vite) web UI to control the device, preview frames, generate images/animations, and schedule modes

## Quick start

### 1) Firmware
Requirements: PlatformIO (VSCode) or `pio` CLI.

1. Open `firmware/` in PlatformIO.
2. Set pins and panel type in `src/config.h`.
3. Build and upload.
4. Device boots, connects to WiFi (see `CONFIG_WIFI_*` in `src/config.h`), then exposes:
   - REST: `http://<device-ip>/api/*`
   - WebSocket frame stream: `ws://<device-ip>/ws/frame`
   - WebSocket events/telemetry: `ws://<device-ip>/ws/events`

### 2) Render service
Requirements: Python 3.10+

```bash
cd render_service
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8787
```

### 3) Dashboard
Requirements: Node 18+

```bash
cd dashboard
npm install
npm run dev
```

Open the dashboard at the printed local URL.
Set:
- Render service URL: `http://localhost:8787`
- Device IP: `http://<device-ip>`

## Notes on "text to image"
This repo includes a pluggable provider interface (`render_service/app/providers/*`).
The default provider is a local procedural pixel-art generator for demo and offline use.
Add your preferred image model in a provider and set `PROVIDER=...` in environment variables.
